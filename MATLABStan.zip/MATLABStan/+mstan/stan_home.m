% Modify the string below so that it points to the parent directory of 
% your CmdStan installation
% TODO
%  o some basic checking
%  o some way to manage fileseparators?
function d = stan_home()

d = '/opt/cmdstan-2.25.0';
%d = 'C:\Users\brian\Downloads\cmdstan';
